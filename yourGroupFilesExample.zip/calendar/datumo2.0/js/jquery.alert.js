(function(jQuery){
	
	/**
	 * JQUERY ALERT PLUGIN
	 * 
	 * @author Jo�o Lagarto (jlagarto@igc.gulbenkian.pt)
	 * 
	 * My first plugin. Still very basic. Needs improvement
	 * Display an alert Message. Can be configurated 
	 * 
	 */
	
	jQuery.fn.startAlert = function(options){
		var element = this;
		//default settings for this plugin
		var defaults = {
			target: "errorNotify",				//div where the message is going to
			style: "alertClass",				//class name
			text: "No message to be displayed", //default message
			fadein: 500,						//time to display message
	        fadeout: 2000, 						//time for the message to leave
	        idle: 5000							//time between fadein and fadeout
	    };
		
		//default styles		
		var options = jQuery.extend({}, defaults, options);
		$("#"+options.target).addClass("alertClass");
		return element;
	};
	
	
	jQuery.fn.alertMsg = function(options){
		//default settings
		var defaults = {
			target: "errorNotify",				//div where the message is going to be displayed
			text: "No message to be displayed", //default message
			fadein: 500,						//time to display message
		    fadeout: 2000, 						//time for the message to leave
		    idle: 5000							//time between fadein and fadeout
		};

		var options = jQuery.extend({}, defaults, options);
		$("#"+options.target).html(options.text);
		$("#"+options.target).slideToggle(options.fadein).idle(options.idle);
		$("#"+options.target).slideToggle(options.fadeout);
		
	};
	
	jQuery.fn.idle = function(time){ 
	      var element = $(this); 
	      element.queue(function(){ 
	         setTimeout(function(){ 
	            element.dequeue(); 
	         }, time);
	      });
	  };

	
})(jQuery);