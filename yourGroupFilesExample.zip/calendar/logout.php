<?php

session_start();
session_destroy();

echo "<meta HTTP-EQUIV='REFRESH' content='0; url=./'>";

?>