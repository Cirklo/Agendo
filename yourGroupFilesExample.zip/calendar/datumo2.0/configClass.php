<?php 

/**
 * @author Jo�o Lagarto
 * @version Datumo 2.0
 * @abstract Datumo configuration. Inhere we check for any plugins available
 * @license EUPL
 * 
 */

class configClass{
	private $pdo;
	private $plugin=array();
	private $menu=array();
	
	public function __construct(){
		$this->pdo = new dbConnection();
	}
	
	public function getPlugins(){	return $this->plugin;}
	public function getMenu(){	return $this->menu;}
	
	
	/**
	 * @author Jo�o lagarto
	 * @abstract Query the database for plugins
	 */
	
	public function checkPlugins(){
		//set search path to main database
		$this->pdo->dbConn();
		$sql=$this->pdo->prepare("SELECT * FROM ".$this->pdo->getDatabase().".plugin");
		$sql->execute();
		for($i=0;$row=$sql->fetch();$i++){
			$arr[]=$row[1];
		}
		$this->plugin=$arr;
		//call method to find submenus
		$this->checkSubmenus();
	}
	
	/**
	 * @author Jo�o lagarto
	 * @abstract Query the database for submenus and data display
	 */
	
	public function checkSubmenus(){
		//set search path to main database
		$this->pdo->dbConn();
		for($i=0;$i<sizeof($this->plugin);$i++){
			echo "<tr><td colspan=2><hr></td></tr>";
			echo "<tr><td>".$this->plugin[$i]."</td></tr>";
			$sql=$this->pdo->prepare("SELECT menu_name, menu_description, menu_url FROM ".$this->pdo->getDatabase().".menu WHERE menu_plugin IN (SELECT plugin_id FROM ".$this->pdo->getDatabase().".plugin WHERE plugin_name='".$this->plugin[$i]."')");
			$sql->execute();
			for($j=0;$row=$sql->fetch();$j++){
				echo "<tr><td><a href=$row[2] title='$row[1]'>$row[0]</a></td></tr>";
			}
		}
	}
	
}















?>