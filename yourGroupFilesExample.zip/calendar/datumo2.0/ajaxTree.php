<?php

require_once (".htconnect.php");
require_once ("treeClass.php");
require_once ("queryClass.php");

//call database class
$conn = new dbConnection();
$engine = $conn->getEngine();
$database = $conn->getDatabase();
//other classes
$tree = new treeClass();

//http variables
if(isset($_GET['id'])) 	$id = $_GET['id'];
if(isset($_GET['table1'])) 	$table1 = $_GET['table1'];
if(isset($_GET['table2'])) 	$table2 = $_GET['table2'];
if(isset($_GET['conn'])) 	$field = $_GET['conn'];
if(isset($_GET['val'])) 	$val = $_GET['val'];
if(isset($_GET['type'])) 	$type = $_GET['type'];
if(isset($_GET['page'])){
	$pageNum = $_GET['page'];
} else {
	$pageNum = 1;
}

//initialize other variables 
$dblConn="";
//variables to handle a great number of results
$rowsPerPage=20;
$offset = ($pageNum-1)*$rowsPerPage;

//control query (number of rows)
$sql = $conn->prepare("SELECT * FROM ".$database.".".$table1." WHERE $field='$val' ORDER BY 2");
try{
	$sql->execute();
	$maxRows = $sql->rowCount();
	$maxPage = ceil($maxRows/$rowsPerPage);
} catch (Exception $e){
	//do nothing for now
}
//display first table options
$sql = $conn->prepare("SELECT * FROM ".$database.".".$table1." WHERE $field='$val' ORDER BY 2 LIMIT 20 OFFSET $offset");
try{
	$sql->execute();
	/**********************PHP CONTAINER TO DISPLAY THE LINKS FOR THE LAST/NEXT 20 ROWS*******************************/
	if($sql->rowCount()>0){
		echo "<b>Showing page $pageNum of $maxPage</b>";
		if($pageNum>1) {
			$page = $pageNum-1;
			echo "&nbsp;&nbsp;<a href=javascript:void(0) onclick=dispTree('$id','$table1','$table2','$field','$val','$page',1,true)>Back</a>";
		} 
		if($pageNum<$maxPage){
			$page = $pageNum+1;
			echo "&nbsp;&nbsp;<a href=javascript:void(0) onclick=dispTree('$id','$table1','$table2','$field','$val','$page',1,true)>Next</a>";
		}
	}
	/*****************************************************************************************************************/
	
} catch (Exception $e){
	//do nothing for now
}
echo "<ul>";
$ref = $table1;
for($j=0;$row = $sql->fetch();$j++){
	if(isset($table2) and $table2!="") {
		$dblConn = $tree->tableConn($table1, $table2);
		$table1=$table2;
		$table2="";
	}
	
	//display first table options
	if($type==1)	echo "<li class=closed><span class='folder' onclick=dispTree('Tree_$row[0]','$table1','$table2','$dblConn','$row[0]',1,2,false);getdetails('details','$ref','$row[0]',true);>$row[1]</span>";
	//if it is the last branch of the tree
	if($type==2) 	echo "<li class=closed><span class=file onclick=getdetails('details','$table1','$row[0]',true)>$row[1]</span>";
	echo "<div id='Tree_$row[0]'></div>";
	echo "</li>";
}
echo "</ul>";

?>