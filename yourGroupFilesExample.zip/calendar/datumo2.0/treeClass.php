<?php

/**
 * @author Jo�o Lagarto / Nuno Moreno
 * @copyright Jo�o Lagarto 2010
 * @license EUPL
 * @version Datumo 2.0
 * @abstract Class to handle reports
 */

class treeClass{
	private $pdo;
	private $query;
	private $name;
	private $description;
	
	public function __construct(){
    	$this->pdo = new dbConnection();
    	$this->query = new queryClass();
    }
	
    public function setTreeviewName($arg){	$this->name=$arg;}
	public function setTreeviewDescription($arg){	$this->description=$arg;}
    
	public function getTreeviewName(){	return $this->name;}
    public function getTreeviewDescription(){	return $this->description;}
    
    
/**
 * @author Jo�o Lagarto / Nuno Moreno
 * @abstract Method to dynamically generate trees
 */
    
    public function genTreeView($tree){
    	//set search path to main database
    	$this->pdo->dbConn();
    	$arr = array();
    	//store all tables in array
    	$arr = $this->treeTables(1);
    	
    	//display first table options
    	$sql = $this->pdo->prepare("SELECT * FROM ".$this->pdo->getDatabase().".".$arr[0]." ORDER BY 2");
    	$sql->execute();
    	echo "<ul id='browser' class='filetree treeview-famfamfam'>";
    	for($i=0;$row=$sql->fetch();$i++) {
    		$conn = $this->tableConn($arr[0], $arr[1]);
    		echo "<li class=closed><a href=javascript:void(0) class='folder' onclick=dispTree('firstTree$i','$arr[1]','$arr[2]','$conn','$row[0]',1,1,false)>$row[1]</a>";
    		echo "<div id=firstTree$i></div>";
  			echo "</li>";
    	}
    	echo "</ul>";
    }
    
/**
 * @author Jo�o Lagarto / Nuno Moreno
 * @abstract Method to get all tables from a tree group
 */
    
    public function treeTables($treeview_id){
    	//get all tables that make part of this tree
    	$sql = $this->pdo->prepare("SELECT treeview_table1,treeview_table2,treeview_table3 FROM ".$this->pdo->getDatabase().".treeview WHERE treeview_id=$treeview_id");
    	$sql->execute();
    	$arr = $sql->fetch();
    	return $arr;
    }
	
    
    public function tableConn($table1, $table2){
    	//set search path to information_schema
    	$this->pdo->dbInfo();
    	//construct array for input parameters.
		$arr = array($this->pdo->getDatabase(),$table1,$table2,'');
		for($i = 0;$i<sizeof($arr);$i++){
			$this->query->__set($i, $arr[$i]);	
		}
		//select engine (mysql or pgsql)
		$this->query->engineHandler($this->pdo->getEngine());
		//query number 1 -> necessary in order to select specific query from vault
		$sql = $this->pdo->prepare($this->query->getSQL(8)); 
		$sql->execute();	
		$row = $sql->fetch();
		//return search path to main database
		$this->pdo->dbConn();
		return $row[0];	
    }
    
/**
 * @author Jo�o Lagarto / Nuno Moreno
 * @abstract Method to handle treeview access
 */
    
    public function treeview_access($user_id){
    	//set search path to main database
    	$this->pdo->dbConn();
    	$sql = $this->pdo->prepare("SELECT treeview_id, treeview_name, treeview_description FROM ".$this->pdo->getDatabase().".treeview WHERE treeview_id IN (SELECT restree_name FROM ".$this->pdo->getDatabase().".restree WHERE restree_user=$user_id)");
    	$sql->execute();
    	echo "<table>";
    	if($sql->rowCount()==0){
    		echo "<tr><td>No treeview reports available!</td></tr>";
    	}else{
    		for($i=0;$row=$sql->fetch();$i++){
    			echo "<tr><td>".($i+1).".</td><td><a href='treeview.php?tree=$row[0]' title='$row[2]'>$row[1]</a> - $row[2]</td></tr>";
    		}	
    	}
    	echo "</table>";
    	
    	
    }
    
/**
 * @author Jo�o Lagarto / Nuno Moreno
 * @abstract Method get treeview information (name and description)
 */
    
    public function treeDesc($treeview_id){
    	//set search path to main database
    	$this->pdo->dbConn();
    	$sql = $this->pdo->prepare("SELECT treeview_id, treeview_name, treeview_description FROM ".$this->pdo->getDatabase().".treeview WHERE treeview_id=$treeview_id");
    	$sql->execute();
    	$row = $sql->fetch();
    	$this->setTreeviewName($row[1]);
    	$this->setTreeviewDescription($row[2]);
    }
    
}



?>