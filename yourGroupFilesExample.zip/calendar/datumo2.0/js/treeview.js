
function dispTree(id,table1, table2, conn, val, page, type, bool){
	var url = "ajaxTree.php?id="+id+"&table1="+table1+"&table2="+table2+"&conn="+conn+"&val="+val+"&page="+page+"&type="+type;
	var str = ajaxRequest(url);
	$("#"+id).html(str);
	if(!bool) treeshow(id);
}

function treeshow(id){
	var obj = document.getElementById(id);
	var allobj = document.getElementsByTagName("div");
	if(obj.style.display == "block")
		obj.style.display = "none";
	else{
		obj.style.display = "block";
	}
	
}