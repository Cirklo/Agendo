<?php

foreach ($_COOKIE as $key => $value) {
     echo "Key: $key; Value: $value<br />\n";
}
?>
