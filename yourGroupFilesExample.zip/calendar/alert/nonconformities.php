#!/usr/bin/php5
<?php

require_once("/var/www/cal/alertClass.php");
require_once("/var/www/cal/.htconnect.php");
$alert= new alert;
$alert->nonconf();


?>

